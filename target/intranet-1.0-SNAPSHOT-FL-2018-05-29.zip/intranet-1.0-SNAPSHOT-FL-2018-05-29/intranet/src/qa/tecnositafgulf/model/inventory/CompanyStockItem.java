package qa.tecnositafgulf.model.inventory;


/**
 * Created by hadi on 1/28/18.
 */

public class CompanyStockItem extends StockItem {
}
