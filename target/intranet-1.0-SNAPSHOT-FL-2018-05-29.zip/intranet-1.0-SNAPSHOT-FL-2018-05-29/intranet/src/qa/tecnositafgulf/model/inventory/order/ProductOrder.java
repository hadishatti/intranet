package qa.tecnositafgulf.model.inventory.order;

public class ProductOrder {
}
