package qa.tecnositafgulf.model.inventory;

/**
 * Created by hadi on 1/28/18.
 */
public class Vendor {

    private Long id;

    private String systemType;

    private String systemName;

    private String systemDetails;

    private String technicalDetails;

    private String supplier;

    private String approvedInstaller;

    private String remarks;
}
