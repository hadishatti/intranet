package qa.tecnositafgulf.model.inventory;

import qa.tecnositafgulf.model.companyInfo.Project;

/**
 * Created by hadi on 1/28/18.
 */
public class ProjectStockItem extends StockItem {
    private Project project;
}
