package qa.tecnositafgulf.searchcriteria.inventory;

public class ProductSupplierSearchCriteria {
}
